package LoginSecurities.LoginSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
